const { cert, initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

const projectId = 'generous-57731';
const rawCredentials = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
if (!rawCredentials) throw new Error('Missing FIREBASE_SERVICE_ACCOUNT_JSON GitHub secret');

let serviceAccount;
try {
  serviceAccount = JSON.parse(rawCredentials);
} catch {
  throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON is not valid JSON');
}
if (serviceAccount.project_id !== projectId) {
  throw new Error(`Service account must belong to Firebase project ${projectId}`);
}

initializeApp({ credential: cert(serviceAccount), projectId });
const db = getFirestore();
const messaging = getMessaging();
const state = db.collection('push_worker_state');

function safeDocId(prefix, id) {
  return `${prefix}_${Buffer.from(String(id)).toString('base64url')}`;
}

async function sendToAllTokens(data) {
  const snapshot = await db.collection('push_tokens').get();
  const docs = snapshot.docs.filter((doc) => typeof doc.get('token') === 'string' && doc.get('token'));
  if (!docs.length) return 0;

  let delivered = 0;
  for (let i = 0; i < docs.length; i += 500) {
    const group = docs.slice(i, i + 500);
    const response = await messaging.sendEachForMulticast({
      tokens: group.map((doc) => doc.get('token')),
      data,
      webpush: { headers: { Urgency: 'high' } },
    });
    delivered += response.successCount;
    const staleDeletes = [];
    response.responses.forEach((result, index) => {
      if (!result.success && [
        'messaging/registration-token-not-registered',
        'messaging/invalid-registration-token',
      ].includes(result.error && result.error.code)) {
        staleDeletes.push(group[index].ref.delete());
      }
    });
    await Promise.all(staleDeletes);
  }
  return delivered;
}

async function getState(docId) {
  const doc = await state.doc(docId).get();
  return doc.exists ? doc.data() : null;
}

async function saveState(docId, value) {
  await state.doc(docId).set({ ...value, checkedAt: FieldValue.serverTimestamp() });
}

async function main() {
  const initRef = state.doc('_meta');
  const initDoc = await initRef.get();
  const isBootstrap = !initDoc.exists || initDoc.get('initialized') !== true;

  const [ordersSnap, offersSnap] = await Promise.all([
    db.collection('orders').select('status', 'device_id', 'order_code').get(),
    db.collection('offers').select('title', 'description').get(),
  ]);

  if (isBootstrap) {
    // First run only records the current state. It does not send old orders/offers.
    for (const order of ordersSnap.docs) {
      await saveState(safeDocId('order', order.id), { status: String(order.get('status') || '') });
    }
    for (const offer of offersSnap.docs) {
      await saveState(safeDocId('offer', offer.id), { seen: true });
    }
    await initRef.set({ initialized: true, checkedAt: FieldValue.serverTimestamp() });
    console.log(`Initial baseline saved for ${ordersSnap.size} orders and ${offersSnap.size} offers; no old notifications sent.`);
    return;
  }

  let orderChanges = 0;
  for (const order of ordersSnap.docs) {
    const docId = safeDocId('order', order.id);
    const previous = await getState(docId);
    const currentStatus = String(order.get('status') || '');
    if (!previous) {
      await saveState(docId, { status: currentStatus });
      continue;
    }
    if (previous.status === currentStatus) continue;

    const statusMessages = {
      'تم التأكيد': 'تم تأكيد طلبك وتجهيزه.',
      'جاري التوصيل': 'طلبك الآن في الطريق إليك.',
      'تم التوصيل': 'تم توصيل طلبك. شكرًا لثقتك بنا.',
      'ملغي': 'تم إلغاء الطلب. تواصل معنا إذا احتجت إلى مساعدة.',
      'قيد الانتظار': 'تم تحديث طلبك.',
    };
    const uid = String(order.get('device_id') || '');
    if (uid) {
      const customerTokens = await db.collection('push_tokens').where('uid', '==', uid).get();
      const tokenDocs = customerTokens.docs.filter((doc) => typeof doc.get('token') === 'string' && doc.get('token'));
      if (tokenDocs.length) {
        const body = `${String(order.get('order_code') || 'طلبك')}: ${statusMessages[currentStatus] || 'تم تحديث حالة طلبك.'}`;
        for (let i = 0; i < tokenDocs.length; i += 500) {
          const group = tokenDocs.slice(i, i + 500);
          const response = await messaging.sendEachForMulticast({
            tokens: group.map((doc) => doc.get('token')),
            data: { title: 'تحديث حالة طلبك', body, url: './', tag: `order-${order.id}` },
            webpush: { headers: { Urgency: 'high' } },
          });
          const stale = [];
          response.responses.forEach((result, index) => {
            if (!result.success && [
              'messaging/registration-token-not-registered',
              'messaging/invalid-registration-token',
            ].includes(result.error && result.error.code)) stale.push(group[index].ref.delete());
          });
          await Promise.all(stale);
        }
      }
    }
    await saveState(docId, { status: currentStatus });
    orderChanges += 1;
  }

  let newOffers = 0;
  for (const offer of offersSnap.docs) {
    const docId = safeDocId('offer', offer.id);
    const previous = await getState(docId);
    if (previous && previous.seen === true) continue;

    const title = String(offer.get('title') || 'عرض جديد').slice(0, 100);
    const body = String(offer.get('description') || 'تعرّف على أحدث عروض متجرنا.').slice(0, 180);
    await sendToAllTokens({ title: `عرض جديد: ${title}`, body, url: './', tag: `offer-${offer.id}` });
    await saveState(docId, { seen: true });
    newOffers += 1;
  }

  await initRef.set({ initialized: true, checkedAt: FieldValue.serverTimestamp() }, { merge: true });
  console.log(`Polling complete: ${orderChanges} changed order(s), ${newOffers} new offer(s) processed.`);
}

main().catch((error) => {
  // Never print credentials or token values to workflow logs.
  console.error('Push polling failed:', error && error.message ? error.message : 'unknown error');
  process.exitCode = 1;
});
