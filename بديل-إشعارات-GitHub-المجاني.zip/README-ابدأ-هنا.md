# بديل مجاني دوري لإشعارات Firebase

يراقب هذا العامل تغيّر حالة الطلبات والعروض كل 15 دقيقة تقريبًا عبر GitHub Actions، ثم يرسل إشعار FCM للأجهزة التي اشتركت في `push_tokens`. أول تشغيل يسجل الحالة الحالية فقط ولا يرسل إشعارات قديمة. هذا حل دوري غير فوري، وقد يتأخر تشغيل GitHub. إذا ظل المستودع العام بلا نشاط 60 يومًا، قد يعطل GitHub الجداول تلقائيًا.

على خطة Firebase المجانية، لدى Firestore حصة 50,000 قراءة مستند يوميًا. العامل يقرأ الطلبات والعروض وسجل الحالة في كل تشغيل؛ لذلك عدد المستندات يؤثر مباشرة في استهلاك الحصة. عند تجاوزها قد تتوقف طلبات Firestore حتى تجدد الحصة. لن تتحول الخطة تلقائيًا إلى مدفوعة ما لم تُفعّل الفوترة. راقب **Firestore → Usage** بعد التجربة.

## الملفات التي ترفعها إلى جذر المستودع

- `firebase-push.js`
- `package.json`
- `package-lock.json`
- `.gitignore`

كما تنشئ ملف GitHub Actions بالمسار `.github/workflows/firebase-push.yml` من المثال الموجود في `firebase-push.yml.example`. لا ترفع الملف المثال بهذا الاسم إلى جذر المستودع؛ GitHub لن يشغله هناك.

## خطوات الإعداد بعد رفع الملفات

1. في Google Cloud Console، أنشئ حساب خدمة مخصصًا للمشروع `generous-57731`، لا تستخدم حساب المالك أو ملف المفتاح الشخصي.
2. امنحه دور `Cloud Datastore User` و`Firebase Cloud Messaging Service Editor`. تنبيه: `Cloud Datastore User` يسمح بقراءة وكتابة بيانات Firestore على مستوى المشروع كله. هذا أوسع من مجموعة واحدة، لذلك أنشئ هوية مخصصة لهذا العامل فقط.
3. أنشئ مفتاح JSON لهذا الحساب. لا ترفعه إلى أي مستودع أو ترسله لأحد.
4. في GitHub: المستودع → **Settings → Secrets and variables → Actions → New repository secret**. الاسم: `FIREBASE_SERVICE_ACCOUNT_JSON`. القيمة: كامل محتوى JSON. بعد حفظه، احذف الملف من التنزيلات. السر غير موجود في الملفات المرفوعة.
5. تأكد أن قاعدة Firestore تسمح لكل مستخدم بإدارة رمزه فقط داخل `push_tokens`، وأن `push_worker_state` غير متاح للمستخدمين. لا تستبدل قواعد Firestore كلها. أضف فقط القاعدة التالية قبل قاعدة المنع العامة، بعد مراجعتها مع القواعد الحالية:

```text
match /push_tokens/{tokenId} {
  allow read: if request.auth != null && resource.data.uid == request.auth.uid;
  allow create, update: if request.auth != null
    && request.resource.data.keys().hasOnly(['uid', 'token', 'updatedAt'])
    && request.resource.data.keys().hasAll(['uid', 'token', 'updatedAt'])
    && request.resource.data.uid == request.auth.uid
    && request.resource.data.token is string
    && request.resource.data.token.size() > 0
    && request.resource.data.token.size() <= 4096
    && request.resource.data.updatedAt == request.time;
  allow delete: if request.auth != null && resource.data.uid == request.auth.uid;
}
```

6. من تبويب GitHub **Actions** فعّل سير العمل إن طلب GitHub ذلك. افتح **Firebase Web Push Poller** ثم **Run workflow**. أول تشغيل يجهز سجل المقارنة. بعده اختبر تغيير حالة طلب أو إنشاء عرض.

## حماية مهمة

الـ workflow يعمل على GitHub-hosted runner. صلاحية GitHub للنشر محدودة إلى قراءة المستودع فقط. لا توجد محفزات pull request، ولا تُطبع المفاتيح أو الرموز في السجل، ومرجعيات Actions مثبتة بمعرّفات commit. رغم ذلك، سر حساب الخدمة حساس: أي كود تضعه مستقبلًا في هذا الـ workflow يمكنه استخدامه. لا توسع triggers ولا تضع كودًا غير موثوق في المسار الذي يشغّل السر. لو انكشف JSON، احذف مفتاحه فورًا من Google Cloud IAM وولّد مفتاحًا جديدًا.

المتجر لا يحتاج Blaze لهذا البديل، لكن استقبال الإشعارات يتطلب موافقة كل مستخدم على جهازه. هذا المشروع لا ينشر Cloud Functions ولا يفعّل خطة مدفوعة.
